require('./app.styl');

document.write(new Date())
